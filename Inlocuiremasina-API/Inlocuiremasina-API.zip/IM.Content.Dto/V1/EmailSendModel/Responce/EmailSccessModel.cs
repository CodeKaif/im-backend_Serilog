﻿namespace IM.Dto.V1.EmailSendModel.Responce
{
    public class EmailSccessModel
    {
        public List<string> to { get; set; }
    }
}

﻿namespace IM.Dto.V1.InsuranceCompany.Request
{
    public class InsuranceCompanyUpdateModel
    {
        public int ic_id { get; set; }

        public string? ic_lang { get; set; }

        public string? ic_name { get; set; }

        public string? ic_image { get; set; }

        public string? ic_desc { get; set; }
    }
}

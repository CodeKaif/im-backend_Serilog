﻿namespace IM.Dto.V1.InsuranceCompany.Response
{
    public class InsuranceCompanyLookupModel
    {
        public int ic_id { get; set; }

        public string ic_lang { get; set; }

        public string ic_name { get; set; }

        public string ic_image { get; set; }

        public string ic_desc { get; set; }
    }
}

﻿namespace IM.Dto.V1
{
    public interface IMappingProfileMarker
    {
    }
}

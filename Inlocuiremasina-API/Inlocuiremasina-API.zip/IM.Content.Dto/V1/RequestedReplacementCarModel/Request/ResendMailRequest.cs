﻿namespace IM.Dto.V1.RequestedReplacementCarModel.Request
{
    public class ResendMailRequest
    {
        public int rrc_id { get; set; }
    }
}

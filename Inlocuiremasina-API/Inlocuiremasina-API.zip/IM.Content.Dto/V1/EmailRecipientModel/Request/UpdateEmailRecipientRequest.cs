﻿namespace IM.Dto.V1.EmailRecipientModel.Request
{
    public class UpdateEmailRecipientRequest
    {
        public int er_id { get; set; }
        public string er_email { get; set; }
    }
}

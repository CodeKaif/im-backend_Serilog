﻿using Microsoft.AspNetCore.Mvc;

namespace IM.Auth.Controllers.V1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class BaseApiController : ControllerBase
    {
    }
}

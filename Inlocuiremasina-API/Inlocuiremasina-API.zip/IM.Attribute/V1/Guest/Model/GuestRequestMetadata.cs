﻿namespace IM.Attribute.V1.Guest.Model
{
    public class GuestRequestMetadata
    {
        public string lang_code { get; set; }
    }
}

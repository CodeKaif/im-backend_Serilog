﻿namespace Auth.Dto.V1
{
    public interface IMappingProfileMarker
    {
    }
}

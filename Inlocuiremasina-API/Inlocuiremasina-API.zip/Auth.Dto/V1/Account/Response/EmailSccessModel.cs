﻿namespace Auth.Dto.V1.Account.Response
{
    public class EmailSccessModel
    {
        public List<string> to { get; set; }
    }
}

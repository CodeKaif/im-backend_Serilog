﻿namespace FileUploader.V1.FileUploadSrvc.Model
{
    public class FileUploadResponse
    {
        public string ImageUrl { get; set; }
        public bool success { get; set; }
    }
}

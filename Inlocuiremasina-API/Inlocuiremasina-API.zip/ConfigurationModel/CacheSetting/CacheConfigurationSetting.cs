﻿namespace ConfigurationModel.CacheSetting
{
    public class CacheConfigurationSetting
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public string Password { get; set; }
    }
}

﻿namespace ConfigurationModel.ServicesEndpoint
{
    public class ServicesEndpoint
    {
        public string ContentApi { get; set; }
        public string AuthApi { get; set; }
        public string NotificationApi { get; set; }
    }
}

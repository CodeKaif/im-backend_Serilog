﻿namespace Auth.Service.Constant
{
    public class ApiEndPointConstant
    {
        public static string SendEmailAsync()
        {
            return "api/v1/email/sendmail";
        }
    }
}

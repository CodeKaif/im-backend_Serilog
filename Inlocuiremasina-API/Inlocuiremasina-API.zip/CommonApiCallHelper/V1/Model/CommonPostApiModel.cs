﻿namespace CommonApiCallHelper.V1.Model
{
    public class CommonPostApiModel  //<T>
    {
        public string lang { get; set; } = "en";  // Default value
        public int userId { get; set; } = 0; // Default value        
    }
}

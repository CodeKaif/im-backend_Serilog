﻿namespace CommonApiCallHelper.V1.Constant
{
    public static class ServiceEndpointConstants
    {
        public static readonly string ContentApi = "ContentApi";
        public static readonly string AuthApi = "AuthApi";
        public static readonly string NotificationApi = "NotificationApi";
    }
}

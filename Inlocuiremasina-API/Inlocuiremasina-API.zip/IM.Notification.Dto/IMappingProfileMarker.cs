﻿namespace IM.Notification.Dto
{
    public interface IMappingProfileMarker
    {
    }
}

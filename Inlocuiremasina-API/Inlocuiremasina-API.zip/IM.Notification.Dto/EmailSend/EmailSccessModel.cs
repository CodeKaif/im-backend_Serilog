﻿namespace IM.Notification.Dto.EmailSend
{
    public class EmailSccessModel
    {
        public List<string> to { get; set; }
    }
}

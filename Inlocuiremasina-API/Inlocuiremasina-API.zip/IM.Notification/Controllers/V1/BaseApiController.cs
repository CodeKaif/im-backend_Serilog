﻿using Microsoft.AspNetCore.Mvc;

namespace IM.Notification.Controllers.V1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class BaseApiController : ControllerBase
    {
    }
}

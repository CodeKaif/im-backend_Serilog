﻿using IM.Domain.Entities.RequestCarDomain;
using IM.Repository.Core.Generic.Interface;

namespace IM.Repository.V1.RequestCarRepository.Interface
{
    public interface IRequestCarRepo : IGenericRepositoryAsync<RequestCar>
    {
    }
}

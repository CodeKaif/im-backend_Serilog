﻿using Microsoft.AspNetCore.Mvc;

namespace IM.Content.Controllers.V1.Guest
{
    [Route("api/v1/guest/[controller]")]
    [ApiController]
    public class BaseApiController : ControllerBase
    {
    }
}
